function y=PLOTT(NE,NN,II,BC,U)
close all
% U=[0 .001 .003 0]; 
X=zeros(NE,4);
Y=zeros(NE,4);
ZY=zeros(NE,4);
ZX=zeros(NE,4);
UU=zeros(NN,2);
for i=1:NN
    UU(i,:)=[U(2*i-1) U(2*i)];
end

%     UU=U;

for i=1:NE
    iii=num2str(i);
    hold on

        X(i,:)=[II(BC(i,1),1) II(BC(i,2),1) II(BC(i,3),1) II(BC(i,4),1)];
        Y(i,:)=[II(BC(i,1),2) II(BC(i,2),2) II(BC(i,3),2) II(BC(i,4),2)];
        ZX(i,:)=[UU(BC(i,1),1) UU(BC(i,2),1) UU(BC(i,3),1) UU(BC(i,4),1)];
        ZY(i,:)=[UU(BC(i,1),2) UU(BC(i,2),2) UU(BC(i,3),2) UU(BC(i,4),2)];
        colormap(jet)
colorbar('hot')
    figure(1)
    axis equal
    xlabel('x')
    ylabel('y')
%     title('standard deviation displacement in x','FontSize',20)
    title('standard deviation stress ','FontSize',20)
%     title('mean stress ','FontSize',20)
% 
%     title(' mean displacement in x','FontSize',20)
    fill(X(i,:),Y(i,:),ZX(i,:))
%     title('horizontal displacement')
%     fill(X(i,:)+ZX(i,:),Y(i,:),ZX(i,:))
%     text((sum(X(i,:))+sum(ZX(i,:)))/4,(sum(Y(i,:)))/4, iii,'FontSize',6)
% %     text((sum(X(i,:))+sum(ZX(i,:)))/4,(sum(Y(i,:)))/4, iii,'FontSize',24,'edgecolor','r')
    figure(2)
    axis equal
        xlabel('x')
    ylabel('y')
    title('standard deviation displacement in y','FontSize',20)
%     title(' mean displacement in y','FontSize',20)
%     title('vertical displacement')
    hold on
    colormap(jet)
    colorbar('hot')
%     fill(X(i,:),Y(i,:),ZY(i,:))
    fill(X(i,:),Y(i,:)+ZY(i,:),ZY(i,:))
%     text((sum(X(i,:)))/4,(sum(Y(i,:))+sum(ZY(i,:)))/4, iii,'FontSize',6)
% %     text((sum(X(i,:)))/4,(sum(Y(i,:))+sum(ZY(i,:)))/4, iii,'FontSize',24,'edgecolor','r')
end
for i=1:NN
%     hold on
    figure(1)
    iii=num2str(i);
%     plot(II(i,1)+100*UU(i,1),II(i,2),'o','Markersize',12)
%     text(II(i,1)+UU(i,1),II(i,2), iii,'FontSize',6,'edgecolor','b')
    text(II(i,1)+UU(i,1),II(i,2), iii,'FontSize',12)
%     hold on
   figure(2) 
   text(II(i,1),II(i,2)+UU(i,2), iii,'FontSize',12)
%    plot(II(i,1),II(i,2)+100*UU(i,2),'o','Markersize',12)
%    text(II(i,1),II(i,2)+100*UU(i,2), ['\leftarrow ',iii],'FontSize',18,'coloredge','b')
% %      text(II(i,1),II(i,2)+UU(i,2), iii,'FontSize',6,'edgecolor','b')
end
hold off


end
function c= c_ijk(M,p)
%% c_{ijk} coefficient in the SSFEM: Projection on homogeneous chaos
%{
--------------------------------------------------------------------------
-------------------------------------------------------

--------------------------------------------------------------------------
*Requires -Hermite_PC- function
*Input:
 M           % number of K-L terms (number of random variables)
 p     % order of PC
 method      % 1 (Sudret's method) or 2 (symbolic integration)
--------------------------------------------------------------------------
*Output:
 c           % c_{ijk} coefficient matrix
--------------------------------------------------------------------------
Based on:
1."Stochastic finite elements A spectral approach"
   R. Ghanem and P.D. Spanos. Rev edition 2012. Dover publications Inc.
2."Stochastic finite element methods and reliability"
   B. Sudret and A. Der Kiureghian. State of the art report.
--------------------------------------------------------------------------
%}

%% procedure
c = cell(M,1);   % memory allocation 

%
alpha               = multi_index(M ,p);        % create the multi-index
[~,~,PsiSqNorm,P] = Hermite_PC(M, p, alpha);  % 1D Hermite polynomials
 % Sudret's method
      for i = 1:M
         c{i} = sparse(P,P);

      end
      c{1} = diag(PsiSqNorm);

%       tic;
      for j = 1:P
         alpha_p = alpha(j,:);
         for k = 1:P
            alpha_q = alpha(k,:);
            for i = 1:M
               idx = [1:(i-1), (i+1):M];
               % Test if alpha_p and alpha_q differ only by i-th coeff
               if isequal(alpha_p(idx), alpha_q(idx))
                  c{i+1}(j,k) = (factorial(alpha_p(i))*(alpha_p(i)-1 == alpha_q(i)) ...
                               + factorial(alpha_q(i))*(alpha_p(i) == alpha_q(i)-1)) ...
                               *(PsiSqNorm(j)/factorial(alpha_p(i)));
               end
            end
         end
      end


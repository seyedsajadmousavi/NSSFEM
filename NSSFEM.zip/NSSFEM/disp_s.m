function DU=disp_s(N,FIX,DU)
% % n=-1;
% %     for i=1:2*N                
% %         if FIX(i,1)==1                     
% %             n=n+1;                   
% %             DU(i-n)=[];
% %         end 
% %     end
 DU(FIX',:)=[];   
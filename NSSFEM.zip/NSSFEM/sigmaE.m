function SE=sigmaE(de,E,v,NE,stress_sta,P,PIi)
SE=cell(P,1);

% EE1=EE(NE,NMCS,E,ey,rr);
for Pj=1:P
    SE{Pj,PIi}=sparse(NE,12);
for i=1:NE
    D=fDe(E{Pj,PIi}(i,:),v,stress_sta);%(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
    SE{Pj,PIi}(i,:)=[(D{1}*de{Pj}(i,1:3)')' (D{2}*de{Pj}(i,4:6)')' (D{3}*de{Pj}(i,7:9)')' ...
        (D{4}*de{Pj}(i,10:12)')'];
end
end
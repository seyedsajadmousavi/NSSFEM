function F=loadding(t,f)
if t<=2
    y=2*10^4*t;
elseif t>2&&t<=3
    y=90000-25000*t;
else
    y=15000;
end
F=y*f;
end
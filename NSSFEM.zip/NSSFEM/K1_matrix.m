function K1=K1_matrix(i,BC,NN,k)
K1=zeros(2*NN,2*NN);
for ii=1:4
    for iii=1:4
        K1(2*BC(i,ii)-1,2*BC(i,iii)-1)=k(2*ii-1,2*iii-1);
        K1(2*BC(i,ii)-1,2*BC(i,iii))=k(2*ii-1,2*iii);         
        K1(2*BC(i,ii),2*BC(i,iii)-1)=k(2*ii,2*iii-1);       
        K1(2*BC(i,ii),2*BC(i,iii))=k(2*ii,2*iii);
    end
end
    
function K=KtT(EE1,v,II,BC,NN,NE,stress_sta,st,NMCS,...
    MKLE,P,cijk)
% P=factorial(MKLE+PC)/(factorial(MKLE)*factorial(PC));
Kc=cell(MKLE+1,1);
K = cell(P,P); 
% K=zeros(2*NN*NMCS,2*NN);
% EE1=EE(NE,NMCS,E,ey,rr);
% rr=rand(NE,NMCS);
% EE=norminv(rr,E',ey');       %%%norminv(p,mu,sigma)
for ii=1:NMCS
%     Kk=zeros(2*NN,2*NN);
%     [lambda,phi,~] = KL_fredholm_analytical(MKLE, b, dombounds); 
% for 
     for j=1:1:MKLE+1
         Kk=zeros(2*NN,2*NN);
         EEm=EE1{j};
%     for ki=1:P
        Kc{j} = sparse(2*NN,2*NN);
%         EEm=EE1{j,ki};
        for i=1:NE
%     for iii=0:MKLE  
    
      
            XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
            lambadaiphiieE=[1 1 1 1];
%         EEm=EE1(i,ii)
            D=fDe(EEm,v,stress_sta);%(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
            k=K_MATRIX(XY,D,st,lambadaiphiieE);
            K1=K1_matrix(i,BC,NN,k);
            Kk=Kk+K1;
       
        end
%         for i=1:MKLE+1
            Kc{j}=Kk;
%         end
%     K((ii-1)*2*NN+1:ii*2*NN,:)=Kk;
%        Kc{iii+1}=Kk;
    end
end
% cijk    = c_ijk(MKLE,PC,1);

% K = cell(P,P);   % full stiffness matrix as a block
for j = 1:P
   for k = 1:P
      K{j,k} = sparse(2*NN,2*NN);
      for i = 1:MKLE+1   % 1 ---> K_0 = Kbar
         if cijk{i}(j,k) ~= 0  % to avoid unnecessary operations
            K{j,k} = K{j,k} + cijk{i}(j,k)*Kc{i};
         end
      end
   end
end
end
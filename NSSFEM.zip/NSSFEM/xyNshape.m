function xy=xyNshape(XY,st)
eta=st(2);
xi=st(1);
           x=((eta + 1)*(xi + 1)/4)*XY(1,1)+(((eta + 1)*(-xi + 1))/4)*XY(2,1)...
               +(((-eta + 1)*(-xi + 1))/4)*XY(3,1)+(((-eta + 1)*(xi + 1))/4)*XY(4,1);
           y=((eta + 1)*(xi + 1)/4)*XY(1,2)+(((eta + 1)*(-xi + 1))/4)*XY(2,2)...
               +(((-eta + 1)*(-xi + 1))/4)*XY(3,2)+(((-eta + 1)*(xi + 1))/4)*XY(4,2);
           xy=[x y];
           
     
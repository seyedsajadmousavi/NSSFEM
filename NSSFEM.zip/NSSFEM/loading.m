function F=loading(t,f)
if t<=2
    y=-2*10^4*t;
elseif t>2&&t<=5.2
    y=-(90000-25000*t);
elseif t>5.2&&t<=6.2
    y=-25000*t+170000;
else
    y=15000;
end
F=y*f;
end
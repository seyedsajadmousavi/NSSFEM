function sy=EEsy(E,ey,rr)
[m ,n]=size(rr);
% E1=zeros(4*m,n);
sy=zeros(n*m,4);
% rr=rand(NE,NMCS);
for i=1:m(1)
    sy(n*(i-1)+1:n*i,:)=norminv(rr(i,:),E(i,:)',ey(i)')';
end
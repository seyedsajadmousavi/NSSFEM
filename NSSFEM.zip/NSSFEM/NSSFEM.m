clc
clear
close all
xmax=0;
xmin=-0;
ymax=0;
ymin=-0;
x=-80:40:80;
y=-80:40:80;
st=[-(1/3)^.5 -(1/3)^.5 ;(1/3)^.5 -(1/3)^.5;(1/3)^.5 (1/3)^.5;-(1/3)^.5 (1/3)^.5];
% x=-80:40:80;
% y=-80:40:80;
dombounds={[min(x) min(y)],[max(x) max(y)]};
b=[max(x)-min(x) max(y)-min(y)];
T=[max(x)+min(x) max(y)+min(y)]*.5;
%  format long 
[NC1,NEf]= AddSurf(xmax,xmin,ymax,ymin,x,y);

NN=size(NC1,1);
% NE=xlsread('q4',1,'b2');
NE=size(NEf,1);
PC=1;
MKLE=4;
% P=factorial(MKLE+PC)/(factorial(MKLE)*factorial(PC));
stress_sta=xlsread('q4',1,'d2');
% II=xlsread('q4',2);
tick=ones(NN,1)*2;
II=[NC1,tick];
% BC=xlsread('q4',3);
BC=NEf;
E1=xlsread('q4',4);
E=E1.*ones(NE,4);
v=xlsread('q4',1,'c2');
U=xlsread('q4',5);
% FIX=xlsread('q4',8);
% FIX=zeros(2*NN,1);
FIX(1)=1;
FIX(2)=2;
FIX(3)=83;
FIX(4)=84;
% FIX(7)=21;
% FIX(8)=22;
% FIX(9)=31;
% FIX(10)=32;
% FIX(3)=41;
% FIX(4)=42;
[FIX,sortfix]=sort(FIX);
% f=xlsread('q4',6);
% f=zeros(2*NN,1);
f=zeros(2*NN,1);
f(5)=6000;
f(9)=6000;
f(13)=6000;
% f(26)=2000;
f(14)=3000;
f(28)=4000;
f(42)=4000;
f(54)=4000;
f(68)=4000;
f(82)=4000;
f(96)=3000;
% f(3)=10000;
% f(5)=10000;
% f(7)=10000;
% f(9)=10000;
% f(20)=-30000;
% f(30)=-30000;
% f(40)=-30000;
% f(3)=6000;
% f(5)=6000;
% f(11)=6000;
% % f(26)=2000;
% f(12)=5000;
% f(32)=5000;
% f(16)=8000;
% f(24)=8000;
ET11=xlsread('q4',7);
ET=ET11.*ones(NE,4);
syy1=xlsread('q4',9);
sy1=syy1.*ones(NE,4);
ey=xlsread('q4',10);%%%std E
ep=xlsread('q4',10);%%%std force R
NMCS=1;
rr=rand(NE,NMCS);
eET=1E-1*ones(NE,4).*ET11;
eE=1E-1*ones(NE,4).*E1;
% E1=abs(EE(E,eE,rr));
% ET1=abs(EE(ET,eET,rr));
Esy=2.35E+1*ones(NE,4)*1;
% sy1=abs(EEsy(sy1,Esy,rr));
ef=.1*f;%+ones(2*NN,1)*.00000001;
% f=Eforc(f,ef',NMCS);
sy=sy1;
dt=1;
t=0:dt:1;
NS=numel(t);
P=factorial(MKLE+PC)/(factorial(MKLE)*factorial(PC));
fixc=[];
for ji = 0:P-1
   fixc = [fixc, (ji*2*NN + FIX)];
end
% sy=ones(NE,4*NS)*Sy(1);
% sy(:,1:4)=Sy;
R=zeros(2*NN*P,NS);
U2=zeros(2*NN*NMCS*P,NS);
% U2(8,:)=0:dt:1;
% U2(7,:)=U2(8,:)*.5;
FF=zeros(2*NN*P,NS);
Sttress=cell(P,1);%
for PIi=1:P
    for PIk=1:1
         Sttress{PIi,PIk}=sparse(NMCS*NE,12*NS);
    end
end
alpha                     = multi_index(MKLE, PC);        % create the multi-index
[Psi_s,Psi_p,PsiSqNorm,P] = Hermite_PC(MKLE, PC, alpha);  % 1D Hermite polynomials
cijk    = c_ijk(MKLE,PC);
[lambda,phi,~] = KL_fredholm_analytical(MKLE, b, dombounds); 
[sy1 ,sy]=SYP(MKLE,BC,sy,Esy,lambda,phi,II,T,NE,st,cijk,P,PsiSqNorm);
[E1 ,E]=SYP(MKLE,BC,E,eE,lambda,phi,II,T,NE,st,cijk,P,PsiSqNorm);
[ET1,ET]=SYP(MKLE,BC,ET,eET,lambda,phi,II,T,NE,st,cijk,P,PsiSqNorm);
K=KtT(E1,v,II,BC,NN,NE,stress_sta,st,NMCS,MKLE,P,cijk);

f=FP(MKLE,P,cijk,f,ef,lambda,phi,II,T,PsiSqNorm);
syy=cell(P,1);
for PIi=1:P
%     for Pj=1:P
        syy{PIi}=zeros(NE*NMCS,4*NS);
%     end
end
K = cell2mat(K); 
f = cell2mat(f);
tic
for i=2:NS
    [U2 ,FF ,R(:,i) ,Sttress,sy]=calculate_displacement(U2,t,NN,i,E,ET,...
        NE,II,f,FF,BC,v,sy,Sttress,stress_sta,NMCS,...
        P,fixc,K,st,syy);
end 
toc
reU= reshape(U2(:,2),2*NN,P);
meanU=(sum(reU')/P)';
EUi2=zeros(2*NN,1);

    for jj=1:P
%         EU2=U2((jj-1)*2*NN+1:(jj)*2*NN,NS)+EU2;
        EUi2=reU(:,jj).^2+EUi2;
    end
%     EU=EU2/NMCS;
    stdU=((EUi2-P*meanU.^2)/(P-1)).^.5;


% cov_U = zeros(2*NN);
% for j = 0:P-1
%    cov_U = cov_U + reU(:,j+1)*reU(:,j+1)'*PsiSqNorm(j+1);
% end
% std_U  = sqrt(diag(cov_U));
stdUx = stdU(1:2:end);
stdUy = stdU(2:2:end);


    x=(meanU(95)-5*stdU(95):.1*stdU(95):meanU(95)+5*stdU(95));
    fx=normpdf(x,meanU(95),stdU(95));
    plot(x,fx)
   MSttress=zeros(NE,3);
    stdMSttress=zeros(NE,3);
% end
    for iii=1:P
        MSttress=MSttress+[(Sttress{iii}(:,13)+Sttress{iii}(:,16)...
            +Sttress{iii}(:,19)+Sttress{iii}(:,22))/4 (Sttress{iii}(:,14)+Sttress{iii}(:,17)...
            +Sttress{iii}(:,20)+Sttress{iii}(:,23))/4 (Sttress{iii}(:,15)+Sttress{iii}(:,18)...
            +Sttress{iii}(:,21)+Sttress{iii}(:,24))/4];
        stdMSttress=([(Sttress{iii}(:,13)+Sttress{iii}(:,16)...
            +Sttress{iii}(:,19)+Sttress{iii}(:,22))/4 (Sttress{iii}(:,14)+Sttress{iii}(:,17)...
            +Sttress{iii}(:,20)+Sttress{iii}(:,23))/4 (Sttress{iii}(:,15)+Sttress{iii}(:,18)...
            +Sttress{iii}(:,21)+Sttress{iii}(:,24))/4]).^2+stdMSttress;
    end

MSttressf=MSttress/P;
stdMSttress=((stdMSttress-P*MSttressf.^2)/(P-1)).^.5; 

MMSttress=MSttressf;

NodeSttressf=zeros(NN,3);
nodestdMSttress=zeros(NN,3);
for ii=1:NN
    cjjj=0;
    for jjj=1:NE
        if NEf(jjj,1)==ii||NEf(jjj,2)==ii||NEf(jjj,3)==ii||NEf(jjj,4)==ii
            cjjj=cjjj+1;
            NodeSttressf(ii,:)=NodeSttressf(ii,:)+MMSttress(jjj,:);
            nodestdMSttress(ii,:)=nodestdMSttress(ii,:)+stdMSttress(jjj,:);
        end
    end
     NodeSttressf(ii,:)=NodeSttressf(ii,:)/cjjj;  
     nodestdMSttress(ii,:)= nodestdMSttress(ii,:)/cjjj;  
            
end

N  = 1e4;
u  = zeros(2*NN, N);
xi = randn(N, MKLE);

% this step is required to evaluate the polynomials (sym form)
xi_v  = sym('xi',[1, MKLE],'real');              % create symbolic vector
xi_n  = num2cell(xi,1);                             % 'experimental design'
func  = matlabFunction(Psi_s(2:end),'Vars',xi_v);   % take out the 1st because it is always one
Psi   = [ones(N,1), func(xi_n{:})];                 % then I add the ones here

% evaluate PCE
for j = 0:P-1
   msg   = fprintf('Evaluating PC expansion %g/%g', j, P);
   psi_j = Psi(:,j+1); 
   reU_j   = reU(:,j+1);
   for i = 1:2*NN
      u(i,:) = u(i,:) + reU_j(i)*psi_j';
   end
   fprintf(repmat('\b',1,msg));
end

% PC approximation of the r.v. at chosen dof 
dof  = 2*NN;
% u_PC = u(dof,:);  % evaluation
u_PC = reU(dof,:);

[n1,x1]         = hist(u_PC,ceil(sqrt(N)));           % histogram 
[PC_pdf,x2,bw1] = ksdensity(u_PC);                    % pdf
[PC_cdf,x3]     = ecdf(u_PC);                         % cdf
%[PC_cdf,x3]     = ksdensity(u_PC,'function','cdf');   % cdf



%% plots
set(0,'defaultTextInterpreter','latex'); 
% pdf
figure; hold on;
bar(x1,n1/trapz(x1,n1),'c','EdgeColor',[0,0,0]);
% plot(x4,PC_pdf_mcs,'b-','LineWidth',2);
plot(x2,PC_pdf,'r--','LineWidth',2); % 'k-+' 'g-.' 'r--'
grid minor; axis tight; xlim([0 3]);
xlabel('$$\xi$$','FontSize',15);
ylabel('$$f_u(\xi)$$','FontSize',15);
legend('Norm Hist','MCS',sprintf('%dth-order PC approx',PC),'Location','Best');
set(gca,'FontSize',15);

% cdf
figure; 
% cdf tail beg
subplot(3,4,[1 2]);
 hold on;
semilogy(x3,PC_cdf,'r--','LineWidth',1);
grid on; axis tight; 
xlabel('$$\xi$$','FontSize',15);
title('$$F_u(\xi)$$','FontSize',15);
set(gca,'FontSize',15);

% cdf tail end
subplot(3,4,[3 4]);
 hold on;
semilogy(x3,1-PC_cdf,'r--','LineWidth',1);
grid on; axis tight; set(gca,'YTick',[]);
xlabel('$$\xi$$','FontSize',15); 
title('$$1-F_u(\xi)$$','FontSize',15);
set(gca,'FontSize',15);

% cdf
subplot(3,4,5:12);
hold on;
plot(x3,PC_cdf,'r--','LineWidth',1);
grid minor; axis tight;
xlabel('$$\xi$$','FontSize',15);
ylabel('$$F_u(\xi)$$','FontSize',15);
% legend('MCS',sprintf('%dth-order PC approx',PC),'Location','Best');
set(gca,'FontSize',15);

% xlswrite('UP3M7',reU,1)
% xlswrite('UP3M7',meanU,2)
% xlswrite('UP3M7',stdU,3)
% xlswrite('UP3M7',stdU,4)
% nodestdMSttress
%  stdnodeSttress=((nodestdMSttress-NMCS*NodeSttressf.^2)/(NMCS-1)).^.5;   
% F=tFF(Sttress(:,12*(i)-11:12*(i)),NE,NN,II,BC,st);
PLOTT(NE,NN,II,BC,nodestdMSttress)
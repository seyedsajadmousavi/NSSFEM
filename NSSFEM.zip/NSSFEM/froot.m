function y=froot(x,a,b)
d=(-x(1)+x(2))/10000;
ff=x(1):d:x(2);
m=numel(ff);
for i=1:m
    f=@(w)(w+tan(w*a)/b);
%     wm=[3*pi 4*pi]
    y=fzero(f,ff(i));
    fw=y+tan(y*a)/b;
    if y>=x(1)&&y<=x(2)&&abs(fw)<10^-5
        break
    end
end
% y


function Seffect=fSeffect(S)
sd=deviatoric_stress(S);
SS=[sd(1,1);sd(2,2);sd(3,3);sd(1,2);sd(1,3);sd(2,3)];
LL=[1 0 0 0 0 0 ;0 1 0 0 0 0;0 0 1 0 0 0;0 0 0 2 0 0;0 0 0 0 2 0;0 0 0 0 0 2];
Seffect=(3*SS'*LL*SS/2)^.5;
% Seffect=(S(1)^2+S(2)^2-S(1)*S(2)+3*S(3)^2)^.5;
function Sd=deviatoric_stress(S)
S1=[S(1) S(3) 0;S(3) S(2) 0;0 0 0];
Sm=trace(S1)/3;
Sd=[S(1)-Sm S(3) 0;S(3) S(2)-Sm 0;0 0 0-Sm];
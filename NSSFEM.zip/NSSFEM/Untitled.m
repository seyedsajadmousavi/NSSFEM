clf
clc
clear 
M=10;
a=100;
x=-a:.01*a:a;
b=200;
Ln=zeros(M,1);
hold on
for i=1:M
    zz=[(i-1)/(2*a)*pi (i)/(2*a)*pi];
    wm=((2*i-1)/(4*a))*pi;
if ceil(i/2)==i/2
%     ss1=(zz(1)+tan(zz(1)*a)/b)*(zz(2)+tan(zz(2)*a)/b);
%     ss2=(zz(2)+tan(zz(2)*a)/b)*(zz(3)+tan(zz(3)*a)/b);
%     if ss1<=0
%         wm=((4*i-3)/(8*a))*pi;
%     else
%         wm=((4*i-1)/(8*a))*pi;
%     end
%    c=1;
%     wm=[3*pi-.1 4*pi-.1];
%     f=@(w)(w+tan(w*a)/b);
    w=froot(zz,a,b);
%     wm=[3*pi 4*pi]
%     w=fzero(f,wm);
%     w=w+c;

ln=1./(a-sin(2*w*a)./(2*w))^.5;
fn=ln.*sin(w*x);
% Ln(i)=2*b/(1+w^2*b^2);
plot(x,fn)
else
%     ss1=(zz(1)+tan(zz(1)*a)/b)*(zz(2)+tan(zz(2)*a)/b);
%     ss2=(zz(2)+tan(zz(2)*a)/b)*(zz(3)+tan(zz(3)*a)/b);
%     if ss1<=0
%         wm=((4*i-3)/(8*a))*pi;
%     else
%         wm=((4*i-1)/(8*a))*pi;
%     end
%     f=@(w)1/b-w.*tan(w*a);
    w=froot1(zz,a,b);
cn=(1./(a+sin(2*w*a)./(2*w)).^.5).*cos(w*x);
% Ln(i)=2/(1+w^2);
plot(x,cn)
end
Ln(i)=2*b/(1+w^2*b^2);
% plot(1:M,Ln)
% w
end


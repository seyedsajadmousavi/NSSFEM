c=0;
for i=1:NN
    c=c+1;
    if NC1(i,:)==[-60 60]
        break
    end
end
    c
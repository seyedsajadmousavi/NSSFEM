function U=U_long(N,U,FIX,U2)
    n=0;

for i=1:2*N      
    if FIX(i,1)==0         
        n=n+1;         
        U(i,:)=U2(n,1);  
    end    
end
function de=strainIncrement(U,BC,II,NE,st,P)
U1=U;
% st=[-(1/3)^.5 -(1/3)^.5 ;(1/3)^.5 -(1/3)^.5;(1/3)^.5 (1/3)^.5;-(1/3)^.5 (1/3)^.5];
de=cell(P,1);
% de=zeros(NE*P,12);
NN=size(II,1);
% ccc=0;
for Pj=1:P
    de{Pj}=sparse(NE,12);
    U=U1(2*NN*(Pj-1)+1:2*NN*Pj,:);
for i=1:NE
%     ccc=ccc+1;
    UNE=zeros(2*4,2);
    XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
%     D=(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
    for ii=1:4
        UNE(2*ii-1,1)=U(2*BC(i,ii)-1,1);
        UNE(2*ii,1)=U(2*BC(i,ii),1);
        UNE(2*ii-1,2)=U(2*BC(i,ii)-1,2);
        UNE(2*ii,2)=U(2*BC(i,ii),2);
    end
    de{Pj}(i,:)=fSTRAIN(st,UNE(:,2),XY)-fSTRAIN(st,UNE(:,1),XY);
%     de(i,:)=[BB_matrix(st(1,:),XY)*UNE(:,2) ;BB_matrix(st(2,:),XY)*UNE(:,2)...
%         ;BB_matrix(st(3,:),XY)*UNE(:,2);BB_matrix(st(4,:),XY)*UNE(:,2)]-...
%         [BB_matrix(st(1,:),XY)*UNE(:,1) ;BB_matrix(st(2,:),XY)*UNE(:,1)...
%         ;BB_matrix(st(3,:),XY)*UNE(:,1);BB_matrix(st(4,:),XY)*UNE(:,1)];
end
end
function stresses=stress(v,E,U,BC,II,NE,st)
% st=[0 0];
% st=[-(1/3)^.5 -(1/3)^.5 ;-(1/3)^.5 (1/3)^.5;(1/3)^.5 (1/3)^.5;(1/3)^.5 -(1/3)^.5];
for i=1:NE
    UNE=zeros(2*4,1);
    XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
    D=(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
    for ii=1:4
        UNE(2*ii-1,:)=U(2*BC(i,ii)-1,:);
        UNE(2*ii,:)=U(2*BC(i,ii),:);
    end
    stresses(i,:)=[D*BB_matrix(st(1,:),XY)*UNE ;D*BB_matrix(st(2,:),XY)*UNE...
        ;D*BB_matrix(st(3,:),XY)*UNE;D*BB_matrix(st(4,:),XY)*UNE];
end
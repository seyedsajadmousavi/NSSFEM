function [eigval,eigfun,eigvec] = KL_fredholm_analytical(M,b,dombounds)
%% Analytical solution of the Fredholm equation for the exponential kernel
%{
--------------------------------------------------------------------------

--------------------------------------------------------------------------
*Only for exponential kernel
*The domain must be symmetric.
--------------------------------------------------------------------------
M         ---> number of KL terms
b         ---> correlation length for each dimension M
dombounds ---> {[xmin ymin],[xmax ymax]}
--------------------------------------------------------------------------
EXAMPLE:
%
M    = 8;
% b    = [1];
% xnod = {[0 1]}; 
b    = [1 1];
xnod = {[0,0] , [1,1]};
close all; [eigval,eigvec] = KL_fredholm_analytical(M,b,xnod);
--------------------------------------------------------------------------
Based on:
1."Stochastic finite elements A spectral approach"
   R. Ghanem and P.D. Spanos. Rev edition (2012). Dover publications Inc.
--------------------------------------------------------------------------
%}

%% domain data
dim = length(dombounds);   % Problem dimension

if dim == 1   % 1D
   %
   a  = (dombounds{1}(2)-dombounds{1}(1))/2;
   xx = sym(sprintf('x_1'));
   [~,lambda,phi] = sol_KL_analytical(M,a,b,xx);
   
   % eigenvalues and eigenvectors
   eigval = lambda(:);
   eigfun = cell(M,1);
   for n = 1:M
      eigfun{n} = matlabFunction(phi{n},'vars','x_1');
   end
   
   % plots
   figure;
   plot(1:M,eigval,'r*-'); grid minor;
   xlabel('Index'); ylabel('Eigenvalues');
   figure;
   xx = -a:0.01*a:a;
   for i = 1:M
      subplot(2,ceil(M/2),i);
      plot(xx,eigfun{i}(xx)); grid minor;
      xlabel('Length'); ylabel(sprintf('Eigenfunction %d',i));
   end
   
elseif dim == 2  % 2D
   x  = 1;   y = 2;
   ax = (dombounds{2}(x)-dombounds{1}(x))/2;
   ay = (dombounds{2}(y)-dombounds{1}(y))/2;
   a  = [ax ay];
   lambda = cell(dim,1);
   phi    = cell(dim,1);
   xx     = cell(dim,1);
   for i = 1:dim
      xx{i} = sym(sprintf('x_%d',i));
      [~,lambda{i},phi{i}] = sol_KL_analytical(M,a(i),b(i),xx{i});
   end
   
   % eigenvalues with double counting
   eigprod = lambda{x}*lambda{y}';
   eigval  = zeros(M,1);
   eigpos  = zeros(M,2);
   for n = 1:M
      [maxcols, rowidx] = max(eigprod);
      [eigmax, j]       = max(maxcols);
      %
      i            = rowidx(j);
      eigval(n)    = eigmax;
      eigpos(n,:)  = [i,j];
      eigprod(i,j) = 0;   % set to zero the current max to find the following
   end
   
   % eigenvectors
   phi_x    = phi{x};
   phi_y    = phi{y};
   eigfun = cell(M,1);
   for n = 1:M
      eigfun{n} = matlabFunction(phi_x{eigpos(n,1)}*phi_y{eigpos(n,2)},...
                                 'vars', {'x_1','x_2'});
   end
   % plots
   set(0,'defaultTextInterpreter','latex'); 
   figure;
   plot(1:M,eigval,'r*-'); grid minor;
   xlabel('Index'); ylabel('Eigenvalues');
   %
   figure;
   xx     = -ax:0.01*ax:ax;
   yy     = -ay:0.01*ay:ay;
   [X,Y]  = meshgrid(xx,yy);
   eigvec = cell(M,1);
   for i = 1:M
      eigvec{i} = eigfun{i}(X,Y);
      %
      subplot(2,ceil(M/2),i);
      %pcolor(X,Y,eigvec{i}); colorbar; colormap bone; shading flat; hold on;
      %[~,hfigc] = contour(X,Y,eigvec{i},15);
      %set(hfigc, 'LineWidth', 1.0, 'Color', [0 0 0]); 
      surfl(X,Y,eigvec{i}); grid minor; colormap bone; 
      xlabel('$$x$$','FontSize',14); ylabel('$$y$$','FontSize',14);
      title(sprintf('$f_%d$',i),'FontSize',14);
      set(gca,'FontSize',12);
   end
   %
else
   error('Non supported dimension');
end
return;

%%
function [omega,lambda,phi] = sol_KL_analytical(M,a,b,xy)

x      = xy;
% c      = 1/b;
% option = optimset('Display','off');
omega  = zeros(M,1);
lambda = zeros(M,1);
phi    = cell(M,1);
% fun_o  = @(ww) c - ww*tan(ww*a);
% fun_e  = @(ww) ww + c*tan(ww*a);

% constants for indexing the point of search
% j = 0;   k = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:M
    zz=[(i-1)/(2*a)*pi (i)/(2*a)*pi];
%     wm=((2*i-1)/(4*a))*pi;
if ceil(i/2)==i/2

%     wm=[3*pi-.1 4*pi-.1];
%     f=@(w)(w+tan(w*a)/b);
    omega(i)=froot(zz,a,b);


ln=1./(a-sin(2*omega(i)*a)./(2*omega(i)))^.5;
phi{i}=ln.*sin(omega(i)*x);
% Ln(i)=2*b/(1+w^2*b^2);
% plot(x,fn)
else

%     f=@(w)1/b-omega(i).*tan(omega(i)*a);
    omega(i)=froot1(zz,a,b);
phi{i}=(1./(a+sin(2*omega(i)*a)./(2*omega(i))).^.5).*cos(omega(i)*x);
% Ln(i)=2/(1+w^2);
% plot(x,cn)
end
lambda(i)=2*b/(1+omega(i)^2*b^2);
% plot(1:M,Ln)
% w
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


return;
%%END;
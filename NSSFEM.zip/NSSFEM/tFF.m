function tF=tFF(stresses,NE,NN,II,BC,st,P,PIi)
% st=[0 0];
% st=[-(1/3)^.5 -(1/3)^.5 ;-(1/3)^.5 (1/3)^.5;(1/3)^.5 (1/3)^.5;(1/3)^.5 -(1/3)^.5];
tF=cell(P,1);
for Pki=1:P
tF{Pki}=sparse(2*NN,1);
for i=1:NE
    XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
    tf=(BB_matrix(st(1,:),XY))'*(stresses{Pki,PIi}(i,1:3))'*XY(1,3)*det(J_matrix(st(1,:),XY))+...
        (BB_matrix(st(2,:),XY))'*(stresses{Pki,PIi}(i,4:6))'*XY(1,3)*det(J_matrix(st(2,:),XY))+...
        (BB_matrix(st(3,:),XY))'*(stresses{Pki,PIi}(i,7:9))'*XY(1,3)*det(J_matrix(st(3,:),XY))+...
       (BB_matrix(st(4,:),XY))'*(stresses{Pki,PIi}(i,10:12))'*XY(1,3)*det(J_matrix(st(4,:),XY)) ;
    for ii=1:4      
        tF{Pki}(2*BC(i,ii)-1,:)=tf(2*ii-1,:)+tF{Pki}(2*BC(i,ii)-1,:);      
        tF{Pki}(2*BC(i,ii),:)=tf(2*ii,:)+tF{Pki}(2*BC(i,ii),:);  
    end
end
end
tF=cell2mat(tF);
end
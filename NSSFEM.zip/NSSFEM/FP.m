function F=FP(MKLE,P,cijk,f,ef,lambda,phi,II,T,PsiSqNorm)
F = cell(P,1);   % since force is deterministic
Fc=cell(MKLE+1,1);
NN=size(f,1);
% [lambda,phi,~] = KL_fredholm_analytical(MKLE, b, dombounds); 
for M=0:MKLE
    if M==0
       Fc{1}=f;
    else
        for mi=1:NN/2
            Fc{M+1}(2*mi-1,1)=(lambda(M))^.5*phi{M}(II(mi,1)-T(1),II(mi,2)-T(2)).*ef(mi*2-1);
            Fc{M+1}(2*mi,1)=(lambda(M))^.5*phi{M}(II(mi,1)-T(1),II(mi,2)-T(2)).*ef(mi*2);
        end
    end
    
end
for j = 1:P
    F{j} = sparse(NN,1);
   for k = 1:P
%         F{k} = sparse(NN,1);
%        if j==1
%            F{1}=f;
%        else
      
%        end
      for i = 1:MKLE+1   % 1 ---> K_0 = Kbar
         if cijk{i}(j,k) ~= 0  % to avoid unnecessary operations
            F{j} = F{j} + cijk{i}(j,k)*Fc{i};
         end
      end
   end
end
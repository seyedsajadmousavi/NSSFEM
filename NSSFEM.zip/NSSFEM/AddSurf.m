function [NC,NE]= AddSurf(xmax,xmin,ymax,ymin,x,y)
% x=0:.25:1;
% y=0:.25:1;
[X, Y]=meshgrid(x,y);
% z=(X.^.0+X.^0)/2;
% s=surface(X,Y,z);
% clf
% xmax=.75;
% xmin=.25;
% ymax=.75;
% ymin=.25;
% [NC,NE]= AddSurf(s,xmax,xmin,ymax,ymin);
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%set present units to N-mm
% AreaName={};
% ret = SM.SetPresentUnits(SM.eUnits.N_mm_C);
XData=X;
YData=Y;
% ZData=s.ZData;
NC=[];%zeros(size(XData,2)*size(XData,1),2);
Nev=zeros(size(XData,2)*size(XData,1),1);
NE=[];%zeros((size(XData,2)-1)*(size(XData,1)-1),4);
nx=size(XData,2);
ny=size(XData,1);
c=0;
cnevar=0;
for i=1:nx    
    for j=1:ny
        cnevar=cnevar+1;

        if XData(1,i)>xmin&&XData(1,i)<xmax&&YData(j,1)>ymin&&YData(j,1)<ymax
           Nev(cnevar,1)=1; 
           
        else
            c=c+1;
           NC(c,:)=[XData(1,i),YData(j,1)] ;
%            c=c+1; 
%            NN= NN+1;
        end
%       NCf(cncf,:)=NC(i,:);
    end
        
    
end
cc=0;
cce=0;
% for i=1:size(XData,2)
%     for j=1:size(XData,1)
for ii=1:nx-1
    
    for jj=1:ny-1
        cc=cc+1;
        cce=cce+1;

        NE(cce,:)=[ii+cc-1-sum(Nev(1:ii+cc-1)) ii+ny+cc-1-sum(Nev(1:ii+ny+cc-1)) ii+ny+1+cc-1-sum(Nev(1:ii+ny+1+cc-1)) ii+cc-sum(Nev(1:ii+cc))];
        XYm=(NC(NE(cce,1),:)+NC(NE(cce,2),:)+NC(NE(cce,3),:)+NC(NE(cce,4),:))/4;
        if XYm(1)>=xmin&&XYm(1)<=xmax&&XYm(2)>=ymin&&XYm(2)<=ymax
           NE(cce,:)=[];
           cce=cce-1;
        end

%        end
        
    end
end

        

end

function Svm=fSVM(S,sy)
Svm=fSeffect(S)-abs(sy);
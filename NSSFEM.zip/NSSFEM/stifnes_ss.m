function K1=stifnes_ss(N,FIX,K1)
% % n=-1;
% %     for i=1:2*N                
% %         if FIX(i,1)==1                      
% %             n=n+1;                   
% %             K1(i-n,:)=[];                        
% %             K1(:,i-n)=[]; 
% %         end 
% %     end
K1(FIX,:)=[];                        
K1(:,FIX)=[];
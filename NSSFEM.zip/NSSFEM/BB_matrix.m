function B=BB_matrix(st,XY)
NS=J_matrix(st,XY)\[(st(2)+1)/4 -(1+st(2))/4 -(1-st(2))/4 (1-st(2))/4;...
    (st(1)+1)/4 (1-st(1))/4 -(-st(1)+1)/4 -(1+st(1))/4];
N1s=NS(1,1);N1t=NS(2,1);
N2s=NS(1,2);N2t=NS(2,2);
N3s=NS(1,3);N3t=NS(2,3);
N4s=NS(1,4);N4t=NS(2,4);

% a=0.25*(XY(1,2)*(st(1)-1)+XY(2,2)*(-st(1)-1)+XY(3,2)*(st(1)+1)+XY(4,2)*(-st(1)+1));
% b=0.25*(XY(1,2)*(st(2)-1)+XY(2,2)*(-st(2)+1)+XY(3,2)*(st(2)+1)+XY(4,2)*(-st(2)-1));
% c=0.25*(XY(1,1)*(st(2)-1)+XY(2,1)*(-st(2)+1)+XY(3,1)*(st(2)+1)+XY(4,1)*(-st(2)-1));
% d=0.25*(XY(1,1)*(st(1)-1)+XY(2,1)*(-st(1)-1)+XY(3,1)*(st(1)+1)+XY(4,1)*(-st(1)+1));
% B1=[a*N1s-b*N1t 0;0 c*N1t-d*N1s;c*N1t-d*N1s a*N1s-b*N1t];
% B2=[a*N2s-b*N2t 0;0 c*N2t-d*N2s;c*N2t-d*N2s a*N2s-b*N2t];
% B3=[a*N3s-b*N3t 0;0 c*N3t-d*N3s;c*N3t-d*N3s a*N3s-b*N3t];
% B4=[a*N4s-b*N4t 0;0 c*N4t-d*N4s;c*N4t-d*N4s a*N4s-b*N4t];
% B=[B1 B2 B3 B4];
B=[N1s 0 N2s 0 N3s 0 N4s 0;0 N1t 0 N2t 0 N3t 0 N4t;N1t N1s N2t N2s N3t N3s N4t N4s];
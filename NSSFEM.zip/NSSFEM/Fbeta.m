function r=Fbeta(S1,S2,sy)
a11=fSVM(S1,sy);
b11=fSVM(S1+S2,sy);
b=[0 a11/(a11-b11)];
c=1;
db=.1;
while db>.000001
    c=c+1;
    F2=fSVM(S1+b(c)*S2,sy);
    F1=fSVM(S1+b(c-1)*S2,sy);
    b1=b(c-1);
    b2=b(c);
%     if a1*a11<0
%         b11=a1;
%     else
%         a11=a1;
%     end
%     b11=fSVM(S1+b(c-1)*S2,sy);
    b(c+1)=b2-(F2/(F1-F2))*(b1-b2);
   db=abs(b(c+1)-b(c));
%    db
end
% c
r=b(c+1);
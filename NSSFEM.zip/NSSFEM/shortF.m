function FF=shortF(FIX,FF,NN)
% %         n=-1; 
% %     for i=1:2*NN                
% %         if FIX(i,1)==1                     
% %             n=n+1;                                             
% %             FF(i-n,:)=[];
% %         end 
% %     end
FF(FIX,:)=[];


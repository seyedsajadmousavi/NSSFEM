function [U2 ,F ,R,Sttress,sy]= calculate_displacement(U2,t,NN,j,E1,ET1,...
    NE,II,f,F,BC,v,sy,Sttress,stress_sta,NMCS,...
    P,fixc,K,st,syy)  

% K = cell2mat(K); 
% 
% % F=FP(MKLE,P,cijk,f,ef,lambda,phi,II,T);
% 
% f = cell2mat(f);
% F(1:2*NN*P,:) = f;
% sy2=zeros(NMCS*NE,4*j);
for i=1:NMCS
    R=t(j)*f;%loadding(t(j),f);%50*t(j)*f;
    F1=R; 
    c=1;



    F1=shortF(fixc,F1,NN*P);
    FF=F(:,j-1);
    DU=disp_s(NN,fixc,U2((i-1)*2*NN*P+1:2*NN*i*P,j-1));
    mse=zeros(2000,1);
    mse(1)=1;
    L=1;
    ddu=1;
%     i
    K2=stifnes_ss(NN,fixc,K((i-1)*2*NN*P+1:i*2*NN*P,:));
      while mse(c)>=1e-2&&c<2000&&ddu>1e-15&&abs(L)>=1e-10

            FF=shortF(fixc,FF,NN);
            du=K2\(F1-FF);
            U0=dis(DU,du);
            DU=U0;
            [U2 ,F]=F_U_long(NN,fixc,U2,F,FF,U0,j,i,P) ;
            de=strainIncrement(U2(:,j-1:j),BC,II,NE,st,P);
%             stresses=cell(P,1);sy1=cell(P,1); SE=cell(P,1);
            PIi=1;
           SE=sigmaE(de,E1,v,NE,stress_sta,P,PIi);
           [stresses,sy1]=yield_Criteria(SE,v,E1,ET1,...
                                   NE,sy,Sttress,de,j,stress_sta,P,PIi,i);

            FF=tFF(stresses,NE,NN,II,BC,st,P,PIi);
%             FF(2*NN+1:2*NN*P,1)=R(2*NN+1:2*NN*P,1);
            dft=R-F(:,j-1);
            dfdt=R-F(:,j);
            c=c+1;
            mse(c)=(sum(dfdt.^2))^.5/(sum(dft.^2))^.5;
            ddu=(sum(du.^2))^.5;
            if c>=11
                L=mse(c)-mse(c-10);
            end

            
%             c=c+1;
      end
      for PIi=1:P
            Sttress{PIi}((i-1)*NE+1:i*NE,12*j-11:12*j)=stresses{PIi};           
            syy{PIi}((i-1)*NE+1:i*NE,:)=sy1{PIi};
      end
end

sy=syy;
% 1
end

function xy=XeYe(XY,st)
xy1=xyNshape(XY,st(1,:));
xy2=xyNshape(XY,st(2,:));
xy3=xyNshape(XY,st(3,:));
xy4=xyNshape(XY,st(4,:));
xy=[xy1;xy2;xy3;xy4];
function E1=EE(E,ey,rr)
% m=size(E);
[m ,n]=size(rr);
E1=zeros(4*m,n);
% rr=rand(NE,NMCS);
for i=1:m(1)
    E1(4*i-3:4*i,:)=norminv(rr(i,:),E(i,:)',ey(i)');
end
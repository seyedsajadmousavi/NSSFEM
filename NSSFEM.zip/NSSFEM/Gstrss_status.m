function [S,sy]=Gstrss_status(S,S1,S2,dide,sy,ET,E,v,stress_sta)
%     Sd=deviatoric_stress(S(1:3));
%     SVM=0.5*(sum(sum(Sd.*Sd)))-(sy(i*2))^2/3;
SVM=fSVM(S,sy);
SVM1=fSVM(S1,sy);
subincrement=7;
if abs(SVM1)<1e-4
   SVM1=0;
end
if SVM>0
    AA=(E*ET)/(E-ET);
    if SVM1<0  
%        sd11=deviatoric_stress(S1(1:3));
%        sd1=[sd11(1,1);sd11(2,2);sd11(3,3);sd11(1,2);sd11(1,3);sd11(2,3)];
%        sd22=deviatoric_stress(S2(1:3));
%        sd2=[sd22(1,1);sd22(2,2);sd22(3,3);sd22(1,2);sd22(1,3);sd22(2,3)];
%        r=r_factor(sd1,sd2,sy);
       r=Fbeta(S1,S2,sy);
       ds1=r*S2(1:3);
       Sc=S1(1:3)+ds1;
       deEP=(1-r)*dide(1:3)/subincrement;
       La=0;
%        subincrement=20;
%        [la ,Dep]=landa((1-r)*dide(1:3),v,E,stress_sta,Sc,AA,sy);
       for i=1:subincrement
           [la ,De]=landa(deEP,v,E,stress_sta,Sc,AA,sy);
           La=La+la;
           dee=deEP-la';
           Sc(1:3)=(De*dee'+Sc')';
%             sy=sy+E*(2*(dee(1)^2+dee(2)^2+dee(3)^2)/3)^.5;
%            sy=sy+ET*(2*(deEP(1)^2+deEP(2)^2+deEP(3)^2)/3)^.5;
%            sy=sy+AA*(2*(la(1)^2+la(2)^2+la(3)^2)/3)^.5;
       end
       sy=sy+AA*(2*(La(1)^2+La(2)^2+La(3)^2)/3)^.5;
       SC(1:3)=Sc;
       S=Sc;
%        if AA==0
         svm=fSVM(SC,sy);
%          svm
           while (svm)>.0001
                [lac] =C_r_y_s(sy,v,E,stress_sta,SC(1:3));
%                 S(1:3)=SC(1:3)-(lac*De*ac)';
                S(1:3)=SC(1:3)-(lac)';
                svm=fSVM(S,sy);
                SC=S;
           end
%            svm
%        else
%            S=SC;
%             sy=fSeffect(SC);
%        end
    else

        Sc=S1;
        deEP=dide(1:3)/subincrement;
        La=0;
%         [la ,Dep]=landa(dide(1:3),v,E,stress_sta,S1,AA,sy);

        for i=1:subincrement
            [la ,De]=landa(deEP,v,E,stress_sta,S1,AA,sy);
            La=La+la;
            dee=deEP-la';
            Sc(1:3)=(De*dee'+Sc')';
%             sy=sy+E*(2*(dee(1)^2+dee(2)^2+dee(3)^2)/3)^.5;
%               sy=sy+ET*(2*(deEP(1)^2+deEP(2)^2+deEP(3)^2)/3)^.5;
%               sy=sy+AA*(2*(la(1)^2+la(2)^2+la(3)^2)/3)^.5;
              
        end
        sy=sy+AA*(2*(La(1)^2+La(2)^2+La(3)^2)/3)^.5;
        SC(1:3)=Sc;
        S=Sc;
%        if AA==0
         svm=fSVM(SC,sy);
%          svm
             while (svm)>.0001
                  [lac] =C_r_y_s(sy,v,E,stress_sta,SC(1:3));
                  S(1:3)=SC(1:3)-(lac)';
                  svm=fSVM(S,sy);
                  SC=S;
             end
             
             
%        else
%            S=SC;
%            sy=fSeffect(SC); 
%        end

    end
end
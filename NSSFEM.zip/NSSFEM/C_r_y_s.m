function [lac,a,De]=C_r_y_s(sy,v,E,stress_sta,s)
%%Correction or return to the yield surface
Fc=fSeffect(s)-abs(sy);
De=fDe1(abs(E),v,stress_sta);
se=fSeffect(s);%(s(1)^2+s(2)^2-s(1)*s(2)+3*s(3)^2)^.5;
a=[2*s(1)-s(2);2*s(2)-s(1);6*s(3)]/(2*se);
% lac=Fc/(a'*De*a+AA);
lac=(Fc/(a'*a))*a;
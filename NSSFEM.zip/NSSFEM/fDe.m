function De=fDe(E,v,stress_sta)
De=cell(4,1);
%%stress_sta: 1: plane stress&&: 0 plane strain
if stress_sta==1
   De{1}=(E(1)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
   De{2}=(E(2)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
   De{3}=(E(3)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
   De{4}=(E(4)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
else
end
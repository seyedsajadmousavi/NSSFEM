function y=dis(U,du)
y=U+du;
end
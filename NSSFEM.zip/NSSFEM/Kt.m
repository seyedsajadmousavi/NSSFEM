function K=Kt(EE1,v,II,BC,NN,NE,stress_sta,st,NMCS,ey,ep,rr,eET,eE,...
    Esy,ef,PC,MKLE,P,dombounds,b,T,cijk,lambda,phi)
% P=factorial(MKLE+PC)/(factorial(MKLE)*factorial(PC));
Kc=cell(MKLE+1,1);
K=zeros(2*NN*NMCS,2*NN);
% EE1=EE(NE,NMCS,E,ey,rr);
% rr=rand(NE,NMCS);
% EE=norminv(rr,E',ey');       %%%norminv(p,mu,sigma)
for ii=1:NMCS
    Kk=zeros(2*NN,2*NN);
%     [lambda,phi,~] = KL_fredholm_analytical(MKLE, b, dombounds); 
for iii=0:MKLE
    for i=1:NE
%     for iii=0:MKLE  
    
      
       XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
       xe1ye1=XeYe(XY,st);
       xeye=xe1ye1-T;
        if iii==0
%            lambadai=1;
%            phii=1;
           EEm=EE1(i,ii)*[1 1 1 1];
           lambadaiphiieE=[1 1 1 1];
       else
           lambadai=lambda(iii);
%            x11=xeye(1,1);
%            x12=xeye(1,2);
%            phii=[phi{iii}(xeye(1,:)) phi{iii}(xeye(2,:)) phi{iii}(xeye(3,:)) phi{iii}(xeye(4,:))];
           EEm=lambadai^.5*eE(i).*[phi{iii}(xeye(1,1),xeye(1,2))...
               phi{iii}(xeye(2,1),xeye(2,2)) phi{iii}(xeye(3,1),xeye(3,2))...
               phi{iii}(xeye(4,1),xeye(4,2))];
           
        end
%         EEm=EE1(i,ii)
       D=fDe(EEm,v,stress_sta);%(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
       k=K_MATRIX(XY,D,st,lambadaiphiieE);
       K1=K1_matrix(i,BC,NN,k);
       Kk=Kk+K1;
       Kc{iii+1}=Kk;
    end
%     K((ii-1)*2*NN+1:ii*2*NN,:)=Kk;
%        Kc{iii+1}=Kk;
end
% cijk    = c_ijk(MKLE,PC,1);

K = cell(P,P);   % full stiffness matrix as a block
for j = 1:P
   for k = 1:P
      K{j,k} = sparse(2*NN,2*NN);
      for i = 1:MKLE+1   % 1 ---> K_0 = Kbar
         if cijk{i}(j,k) ~= 0  % to avoid unnecessary operations
            K{j,k} = K{j,k} + cijk{i}(j,k)*Kc{i};
         end
      end
   end
end
end
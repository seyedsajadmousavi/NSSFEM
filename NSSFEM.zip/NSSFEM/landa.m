 function [la ,De]=landa(de,v,E,stress_sta,s,AA,sy)
% s:stress in a Gaussian point
%de: strain rate
%De: elastic stress_strain matrix
% se1=[s(1) s(3) 0;s(3) s(2) 0;0 0 0];
% se2=se1-trace(se1)*eye(3);
De=fDe1(E,v,stress_sta);
% se=(s(1)^2+s(2)^2-s(1)*s(2)+3*s(3)^2)^.5;
se=fSeffect(s);
a=[2*s(1)-s(2);2*s(2)-s(1);6*s(3)]/(2*se);
AA1=AA*s*a/sy;
% if s*a/sy>1
%     s*a/sy
% end
la=(a'*De*de'/(a'*De*a+AA1))*a;
% Dep=De-De*a*(a')*De/((a')*De*a+AA1);
% sd=deviatoric_stress(s);
% S1=(E/(1-v^2))*(sd(1,1)+v*sd(2,2));
% S2=(E/(1-v^2))*(sd(2,2)+v*sd(1,1));
% S6=(E/(1+v))*sd(1,2);
% S=(4/9)*se*AA+S1*sd(1,1)+S2*sd(2,2)+2*S6*sd(1,2);
% Dp=[S1^2 S1*S2 S1*S6;S1*S2 S2^2 S2*S6;S1*S6 S2*S6 S6^2]/S;
% la=Dp*de';
% Dep=De-Dp;
% la=1-Dep/De
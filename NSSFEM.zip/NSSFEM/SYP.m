function [SY, SYp]=SYP(MKLE,BC,sy,Esy,lambda,phi,II,T,NE,st,cijk,P,PsiSqNorm)
% F = cell(P,1);   % since force is deterministic
SY=cell(MKLE+1,1);
SYp=cell(P,1);

for iii=0:MKLE
    for i=1:NE
      
    
      
       XY=[II(BC(i,1),:);II(BC(i,2),:);II(BC(i,3),:);II(BC(i,4),:)];
       xe1ye1=XeYe(XY,st);
       xeye=xe1ye1-T;
        if iii==0
%            lambadai=1;
%            phii=1;
           SY{iii+1}(i,:)=sy(i,:);
%            lambadaiphiieE=[1 1 1 1];
       else
           lambadai=lambda(iii);
%            x11=xeye(1,1);
%            x12=xeye(1,2);
%            phii=[phi{iii}(xeye(1,:)) phi{iii}(xeye(2,:)) phi{iii}(xeye(3,:)) phi{iii}(xeye(4,:))];
           SY{iii+1}(i,:)=lambadai^.5*Esy(i,:).*[phi{iii}(xeye(1,1),xeye(1,2))...
               phi{iii}(xeye(2,1),xeye(2,2)) phi{iii}(xeye(3,1),xeye(3,2))...
               phi{iii}(xeye(4,1),xeye(4,2))];
           
        end
    end

end
for j = 1:P
    SYp{j} = sparse(NE,4);
   for k = 1:P

%       SYp{j,k} = sparse(NE,4);
%       /PsiSqNorm(k)

      for i = 1:MKLE+1   % 1 ---> K_0 = Kbar cijk{i}(j,k)*
         if cijk{i}(j,k) ~= 0  % to avoid unnecessary operations
            SYp{j}  = SYp{j}  + cijk{i}(j,k)*SY{i};
         end
      end
   end
end

function [Sq,sy]=yield_Criteria(SE,v,E,ET,NE,sy,Sttress,de,j,stress_sta,P,PIi,NMCS)
Sq=cell(P,1);
for Pki=1:P
Sq{Pki,PIi}=sparse(NE,12);
% St=stress(v,E,U2,BC,II,NE);
Stdt=Sttress{Pki,PIi}((NMCS-1)*NE+1:NMCS*NE,12*(j-1)-11:12*(j-1))+SE{Pki,PIi};
% SVM=zeros(NE,4);
for i=1:NE
%     De=fDe(EE(i),v,stress_sta);%(E(i)/(1-v^2))*[1 v 0;v 1 0;0 0 (1-v)/2];
    dide=de{Pki}(i,:);
    S1=Sttress{Pki,PIi}(i,:);%%stresses in  Gaussian points in a element step m
    S2=SE{Pki,PIi}(i,:);%stress rate
    S=Stdt(i,:);%totla S1+S2 
    
    [Sq{Pki,PIi}(i,1:3),sy{Pki,PIi}(i,4*j-3)]=Gstrss_status(S(1:3),S1(1:3),S2(1:3),dide(1:3),(sy{Pki,PIi}(i,4*(j-1)-3)),(ET{Pki,PIi}(i,1)),(E{Pki,PIi}(i,1)),v,stress_sta);
    [Sq{Pki,PIi}(i,4:6),sy{Pki,PIi}(i,4*j-2)]=Gstrss_status(S(4:6),S1(4:6),S2(4:6),dide(4:6),(sy{Pki,PIi}(i,4*(j-1)-2)),(ET{Pki,PIi}(i,2)),(E{Pki,PIi}(i,2)),v,stress_sta);
    [Sq{Pki,PIi}(i,7:9),sy{Pki,PIi}(i,4*j-1)]=Gstrss_status(S(7:9),S1(7:9),S2(7:9),dide(7:9),(sy{Pki,PIi}(i,4*(j-1)-1)),(ET{Pki,PIi}(i,3)),(E{Pki,PIi}(i,3)),v,stress_sta);
    [Sq{Pki,PIi}(i,10:12),sy{Pki,PIi}(i,4*j)]=Gstrss_status(S(10:12),S1(10:12),S2(10:12),dide(10:12),(sy{Pki,PIi}(i,4*(j-1))),(ET{Pki,PIi}(i,4)),(E{Pki,PIi}(i,4)),v,stress_sta);

end
end
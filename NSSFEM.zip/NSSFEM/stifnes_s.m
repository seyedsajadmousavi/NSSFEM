function U2=stifnes_s(N,FIX,K,F)
K1=K;
F1=F;
n=-1;
    for i=1:2*N                
        if FIX(i)==1                     
            n=n+1;                   
            K1(i-n,:)=[];                        
            K1(:,i-n)=[]; 
            F1(i-n,:)=[];
        end 
    end
    U2=K1\F1;
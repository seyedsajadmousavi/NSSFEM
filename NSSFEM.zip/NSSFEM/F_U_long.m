function [U ,F]=F_U_long(N,FIX,U,F,FF,U0,j,ii,P)
%     n=1;

% for i=1:2*N*P%(ii-1)*2*N+1:2*N*ii      
%     if FIX(n,1)==i         
dd = setdiff(1:(2*N*P),FIX); 
U(dd,j)=U0;
F(dd,j)=FF;
%         U((ii-1)*2*N+i,j)=U0(n,1);  
%         F(i,j)=FF(n,1); 
%         n=n+1;
%     end    
% end
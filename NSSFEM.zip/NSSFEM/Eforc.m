function f=Eforc(f,ey,NMCS)
% m=size(E);
rr=rand(1,NMCS);

    f=norminv(rr,f,ey');

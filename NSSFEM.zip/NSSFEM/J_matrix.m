function j=J_matrix(st,XY)
N1s=(st(2)+1)/4;N1t=(st(1)+1)/4;
N2s=-(1+st(2))/4;N2t=(-st(1)+1)/4;
N3s=-(1-st(2))/4;N3t=-(-st(1)+1)/4;
N4s=(1-st(2))/4;N4t=-(1+st(1))/4;
Xs=N1s*XY(1,1)+N2s*XY(2,1)+N3s*XY(3,1)+N4s*XY(4,1);
Ys=N1s*XY(1,2)+N2s*XY(2,2)+N3s*XY(3,2)+N4s*XY(4,2);
Xt=N1t*XY(1,1)+N2t*XY(2,1)+N3t*XY(3,1)+N4t*XY(4,1);
Yt=N1t*XY(1,2)+N2t*XY(2,2)+N3t*XY(3,2)+N4t*XY(4,2);
j=[Xs Ys;Xt Yt];


% j=(1/8)*XY(:,1)'*[0 1-st(2) st(2)-st(1) st(1)-1;st(2)-1 0 st(1)+1 -(st(1)...
%     +st(2));st(1)-st(2) -(st(1)+1) 0 st(2)+1;1-st(1) st(1)+st(2)...
%     -(st(2)+1) 0]*XY(:,2);
end